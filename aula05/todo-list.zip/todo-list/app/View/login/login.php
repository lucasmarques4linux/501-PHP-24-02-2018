<h2>Login de Usuário</h2>
<form action="?r=login/logginin" method="POST">
	<p>Email:<input type="email" name="email" required></p>	
	<p>Senha:<input type="password" name="senha" required></p>	
	<p><input type="submit" value="Login" class="btn btn-default"></p>
</form>