<?php 

namespace Model\Mapper;

use Model\DAO\TarefasDAO;

class TarefasMapper extends TarefasDAO
{
	protected $entity = 'Model\Entity\Tarefas';

}