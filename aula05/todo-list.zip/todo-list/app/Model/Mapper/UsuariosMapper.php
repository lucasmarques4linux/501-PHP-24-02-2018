<?php 

namespace Model\Mapper;

use Model\DAO\UsuariosDAO;

class UsuariosMapper extends UsuariosDAO
{
	protected $entity = 'Model\Entity\Usuarios';

}